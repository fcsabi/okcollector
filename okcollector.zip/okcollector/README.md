# Szógyűjtő program

Szavak gyűjtése keresztrejtvény készítő programok számára