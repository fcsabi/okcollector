package models;

import java.sql.Connection;

public class Jsoup {

    public static Connection connect(String url) {
        return null;
    }

}
