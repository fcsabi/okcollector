/*
 * File: CheckUrl.java
 * Created Date: 2021-09-24 15:50:04
 * Author: Sallai Andras
 * Github: https://github.com/andteki
 * -----
 * Last Modified: 2022-11-21
 * Modified By: Farkas Csaba
 * -----
 * Copyright (c) 2021 Sallai Andras
 * 
 * GNU GPL v2
 */

package models;

public class CheckUrl {
    // TODO: beírt URL ellenőrző
    public void check(String url) {

    }//URL ellenőrzés vége
    // TODO: ha nincs https:// akkor kiegészítjük
    public void expandProtocol() {

    }//URL kiegészítés vége
}
